const TeacherPage = () => {
  return <div>TeacherPage</div>;
};

export default TeacherPage;
