const StudentPage = () => {
  return <div>StudentPage</div>;
};

export default StudentPage;
