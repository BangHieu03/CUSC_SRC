const ParentPage = () => {
  return <div>ParentPage</div>;
};

export default ParentPage;
