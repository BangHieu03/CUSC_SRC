const Homepage = () => {
  return (
    <div className=''>Homepage</div>
  )
}

export default Homepage